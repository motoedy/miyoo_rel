C-Dogs SDL
==========

C-Dogs SDL is a classic overhead run-and-gun game, supporting up to 4 players
in co-op and deathmatch modes. Customize your player, choose from many weapons,
and blast, slide and slash your way through over 100 user-created campaigns.
Have fun!

Homepage: https://github.com/cxong/cdogs-sdl

Default controls:
-----------------

D-pad/joystick  Moves
A               Shoot
B               Slide/strafe/switch weapons (configure in options)
L-shoulderpad   View map
Select          Exit/Quit
Start           Menu select option

Ported by:
----------

David Knight
18/08/2014
